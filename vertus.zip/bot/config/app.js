const app = {
  version: "1.0.0",
  apiUrl: "https://api.thevertus.app",
  peer: "Vertus_App_bot",
  bot: "Vertus_App_bot",
  webviewUrl: "https://thevertus.app/",
  origin: "https://thevertus.app/",
  referer: "https://thevertus.app/",
  comboUrl: "https://freddywhest.github.io/rocky-rabbit-combos/data.json",
};

module.exports = app;
