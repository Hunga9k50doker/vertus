const banner = `
╔╗  ╔╗        ╔╗         ╔══╗      ╔╗ 
║╚╗╔╝║       ╔╝╚╗        ║╔╗║     ╔╝╚╗
╚╗║║╔╝╔══╗╔═╗╚╗╔╝╔╗╔╗╔══╗║╚╝╚╗╔══╗╚╗╔╝
 ║╚╝║ ║╔╗║║╔╝ ║║ ║║║║║══╣║╔═╗║║╔╗║ ║║ 
 ╚╗╔╝ ║║═╣║║  ║╚╗║╚╝║╠══║║╚═╝║║╚╝║ ║╚╗
  ╚╝  ╚══╝╚╝  ╚═╝╚══╝╚══╝╚═══╝╚══╝ ╚═╝
© Tool được phát triển bởi nhóm tele Airdrop Hunter Siêu Tốc https://t.me/airdrophuntersieutoc

Starting bot.......
`;

module.exports = banner;
